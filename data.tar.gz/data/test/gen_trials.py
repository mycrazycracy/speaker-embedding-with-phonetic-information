import sys

trials = sys.argv[1]
key = sys.argv[2]
new_trials = sys.argv[3]

utt2key = {}

with open(key, 'r') as f:
    for line in f.readlines():
        [spk, utt] = line.strip().split("|")
        utt2key[utt] = spk

fp_out = open(new_trials, "w") 
with open(trials, "r") as f:
    for line in f.readlines():
        [spk, utt] = line.strip().split("|")
        if utt2key[utt] == spk:
            type = "target"
        else:
            type = "nontarget"

        fp_out.write("%s %s %s\n" % (spk, utt, type))

fp_out.close()
